/**
 * Finova Financial Services - Interactive EMI Calculator
 * Reducing-Balance Formula calculation (frontend-only)
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        const calcContainer = document.getElementById('finovaEmiCalculator');
        if (!calcContainer) return;

        // Input Elements
        const amountInput = document.getElementById('emiAmountInput');
        const amountSlider = document.getElementById('emiAmountSlider');
        const rateInput = document.getElementById('emiRateInput');
        const rateSlider = document.getElementById('emiRateSlider');
        const tenureInput = document.getElementById('emiTenureInput');
        const tenureSlider = document.getElementById('emiTenureSlider');

        // Toggle Buttons
        const yearsBtn = document.getElementById('emiTenureYearsBtn');
        const monthsBtn = document.getElementById('emiTenureMonthsBtn');
        const tenureUnitLabel = document.getElementById('emiTenureUnitLabel');
        const tenureTicks = document.getElementById('emiTenureTicks');

        // Buttons
        const recalcBtn = document.getElementById('emiRecalculateBtn');
        const resetBtn = document.getElementById('emiResetBtn');

        // Result Elements
        const monthlyResult = document.getElementById('emiMonthlyResult');
        const principalResult = document.getElementById('emiPrincipalResult');
        const interestResult = document.getElementById('emiInterestResult');
        const totalResult = document.getElementById('emiTotalResult');
        const ratioPrincipal = document.getElementById('emiRatioPrincipal');
        const ratioInterest = document.getElementById('emiRatioInterest');
        const ratioPrincipalText = document.getElementById('emiRatioPrincipalText');
        const ratioInterestText = document.getElementById('emiRatioInterestText');
        const alertBox = document.getElementById('emiCalcAlert');
        const alertMsg = document.getElementById('emiCalcAlertMessage');

        let isYears = true;

        // Default values from data attributes or fallbacks
        const defaultAmount = parseFloat(calcContainer.dataset.defaultAmount) || 50000;
        const defaultRate = parseFloat(calcContainer.dataset.defaultRate) || 8.5;
        const defaultTenure = parseFloat(calcContainer.dataset.defaultTenure) || 5;

        // Sync slider with input
        function bindSync(input, slider, isFloat) {
            if (!input || !slider) return;
            slider.addEventListener('input', function() {
                input.value = slider.value;
                calculateEMI();
            });
            input.addEventListener('input', function() {
                const val = isFloat ? parseFloat(input.value) : parseInt(input.value, 10);
                if (!isNaN(val) && val >= parseFloat(slider.min) && val <= parseFloat(slider.max)) {
                    slider.value = input.value;
                }
                calculateEMI();
            });
        }

        bindSync(amountInput, amountSlider, false);
        bindSync(rateInput, rateSlider, true);
        bindSync(tenureInput, tenureSlider, false);

        // Tenure Unit Toggle
        if (yearsBtn && monthsBtn) {
            yearsBtn.addEventListener('click', function() {
                if (isYears) return;
                isYears = true;
                yearsBtn.classList.add('finova-toggle-btn--active');
                yearsBtn.setAttribute('aria-pressed', 'true');
                monthsBtn.classList.remove('finova-toggle-btn--active');
                monthsBtn.setAttribute('aria-pressed', 'false');

                // Convert months to years
                let currentVal = parseInt(tenureInput.value, 10) || 60;
                let converted = Math.max(1, Math.round(currentVal / 12));
                tenureSlider.min = '1';
                tenureSlider.max = '30';
                tenureSlider.step = '1';
                tenureSlider.value = converted;
                tenureInput.value = converted;
                if (tenureUnitLabel) tenureUnitLabel.textContent = 'Yr';
                if (tenureTicks) {
                    tenureTicks.innerHTML = '<span>1 Yr</span><span>15 Yrs</span><span>30 Yrs</span>';
                }
                calculateEMI();
            });

            monthsBtn.addEventListener('click', function() {
                if (!isYears) return;
                isYears = false;
                monthsBtn.classList.add('finova-toggle-btn--active');
                monthsBtn.setAttribute('aria-pressed', 'true');
                yearsBtn.classList.remove('finova-toggle-btn--active');
                yearsBtn.setAttribute('aria-pressed', 'false');

                // Convert years to months
                let currentVal = parseInt(tenureInput.value, 10) || 5;
                let converted = Math.max(12, currentVal * 12);
                tenureSlider.min = '6';
                tenureSlider.max = '360';
                tenureSlider.step = '6';
                tenureSlider.value = converted;
                tenureInput.value = converted;
                if (tenureUnitLabel) tenureUnitLabel.textContent = 'Mo';
                if (tenureTicks) {
                    tenureTicks.innerHTML = '<span>6 Mo</span><span>180 Mo</span><span>360 Mo</span>';
                }
                calculateEMI();
            });
        }

        function formatCurrency(num) {
            return '$' + num.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function formatWholeCurrency(num) {
            return '$' + Math.round(num).toLocaleString('en-US');
        }

        function showError(msg) {
            if (alertBox && alertMsg) {
                alertMsg.textContent = msg;
                alertBox.style.display = 'flex';
            }
        }

        function hideError() {
            if (alertBox) {
                alertBox.style.display = 'none';
            }
        }

        // Calculation core function
        function calculateEMI() {
            const P = parseFloat(amountInput.value);
            const annualRate = parseFloat(rateInput.value);
            const tenureVal = parseInt(tenureInput.value, 10);

            // Validation
            if (isNaN(P) || P <= 0) {
                showError('Please enter a valid loan amount greater than zero.');
                return;
            }
            if (isNaN(annualRate) || annualRate < 0) {
                showError('Please enter a valid non-negative interest rate percentage.');
                return;
            }
            if (isNaN(tenureVal) || tenureVal <= 0) {
                showError('Please enter a valid loan tenure duration.');
                return;
            }

            hideError();

            // Total months (n)
            const n = isYears ? tenureVal * 12 : tenureVal;

            let emi = 0;
            if (annualRate === 0) {
                // Zero interest handling: EMI = P / n
                emi = P / n;
            } else {
                // Monthly interest decimal rate: r = (AnnualRate / 12) / 100
                const r = (annualRate / 12) / 100;
                // Standard reducing-balance formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
                const factor = Math.pow(1 + r, n);
                emi = (P * r * factor) / (factor - 1);
            }

            const totalRepayment = emi * n;
            const totalInterest = Math.max(0, totalRepayment - P);

            // Update DOM display
            if (monthlyResult) monthlyResult.textContent = formatCurrency(emi);
            if (principalResult) principalResult.textContent = formatWholeCurrency(P);
            if (interestResult) interestResult.textContent = formatWholeCurrency(totalInterest);
            if (totalResult) totalResult.textContent = formatWholeCurrency(totalRepayment);

            // Update Visual Ratio Bar
            const principalPct = Math.round((P / totalRepayment) * 100);
            const interestPct = 100 - principalPct;
            if (ratioPrincipal) ratioPrincipal.style.width = principalPct + '%';
            if (ratioInterest) ratioInterest.style.width = interestPct + '%';
            if (ratioPrincipalText) ratioPrincipalText.textContent = 'Principal: ' + principalPct + '%';
            if (ratioInterestText) ratioInterestText.textContent = 'Interest: ' + interestPct + '%';
        }

        // Reset button
        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                amountInput.value = defaultAmount;
                amountSlider.value = defaultAmount;
                rateInput.value = defaultRate;
                rateSlider.value = defaultRate;

                if (!isYears && yearsBtn) {
                    yearsBtn.click();
                } else {
                    tenureInput.value = defaultTenure;
                    tenureSlider.value = defaultTenure;
                }
                calculateEMI();
            });
        }

        if (recalcBtn) {
            recalcBtn.addEventListener('click', calculateEMI);
        }

        // Initial run
        calculateEMI();
    });
})();
