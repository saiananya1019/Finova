/**
 * Finova Financial Services - Form Validation & Demonstration Handlers
 * Client-side only. No data persisted in storage. No backend requests.
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // ==========================================
        // 1. Sign In Form Handler
        // ==========================================
        const signInForm = document.getElementById('finovaSignInForm');
        if (signInForm) {
            const emailInput = document.getElementById('signInEmail');
            const passwordInput = document.getElementById('signInPassword');
            const emailError = document.getElementById('signInEmailError');
            const passwordError = document.getElementById('signInPasswordError');
            const feedbackAlert = document.getElementById('signInFeedbackAlert');
            const feedbackMsg = document.getElementById('signInFeedbackMessage');
            const feedbackIcon = document.getElementById('signInFeedbackIcon');
            const pwToggle = document.getElementById('signInPwToggle');
            const pwToggleText = document.getElementById('signInPwToggleText');

            // Password Show/Hide Toggle
            if (pwToggle && passwordInput) {
                pwToggle.addEventListener('click', function() {
                    const isPassword = passwordInput.getAttribute('type') === 'password';
                    passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
                    if (pwToggleText) {
                        pwToggleText.textContent = isPassword ? 'Hide' : 'Show';
                    }
                });
            }

            signInForm.addEventListener('submit', function(e) {
                e.preventDefault();
                let isValid = true;

                // Validate Email
                if (!emailInput.value.trim() || !EMAIL_REGEX.test(emailInput.value.trim())) {
                    emailError.style.display = 'block';
                    emailInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    emailError.style.display = 'none';
                    emailInput.classList.remove('finova-form-input--error');
                }

                // Validate Password
                if (!passwordInput.value) {
                    passwordError.style.display = 'block';
                    passwordInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    passwordError.style.display = 'none';
                    passwordInput.classList.remove('finova-form-input--error');
                }

                if (isValid) {
                    // Display demonstration message
                    feedbackAlert.className = 'finova-alert finova-alert--info';
                    feedbackIcon.innerHTML = '&#9432;';
                    feedbackMsg.textContent = 'This is a demonstration sign-in page. No real authentication has been performed.';
                    feedbackAlert.style.display = 'flex';

                    // Clear password field safely without saving
                    passwordInput.value = '';
                }
            });
        }

        // ==========================================
        // 2. Sign Up Form Handler
        // ==========================================
        const signUpForm = document.getElementById('finovaSignUpForm');
        if (signUpForm) {
            const nameInput = document.getElementById('signUpName');
            const emailInput = document.getElementById('signUpEmail');
            const passwordInput = document.getElementById('signUpPassword');
            const confirmInput = document.getElementById('signUpConfirmPassword');
            const termsInput = document.getElementById('signUpTerms');

            const nameError = document.getElementById('signUpNameError');
            const emailError = document.getElementById('signUpEmailError');
            const passwordError = document.getElementById('signUpPasswordError');
            const confirmError = document.getElementById('signUpConfirmPasswordError');
            const termsError = document.getElementById('signUpTermsError');

            const feedbackAlert = document.getElementById('signUpFeedbackAlert');
            const feedbackMsg = document.getElementById('signUpFeedbackMessage');
            const feedbackIcon = document.getElementById('signUpFeedbackIcon');

            signUpForm.addEventListener('submit', function(e) {
                e.preventDefault();
                let isValid = true;

                // Validate Name
                if (!nameInput.value.trim()) {
                    nameError.style.display = 'block';
                    nameInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    nameError.style.display = 'none';
                    nameInput.classList.remove('finova-form-input--error');
                }

                // Validate Email
                if (!emailInput.value.trim() || !EMAIL_REGEX.test(emailInput.value.trim())) {
                    emailError.style.display = 'block';
                    emailInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    emailError.style.display = 'none';
                    emailInput.classList.remove('finova-form-input--error');
                }

                // Validate Password length >= 8
                if (!passwordInput.value || passwordInput.value.length < 8) {
                    passwordError.style.display = 'block';
                    passwordInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    passwordError.style.display = 'none';
                    passwordInput.classList.remove('finova-form-input--error');
                }

                // Validate Confirm Password
                if (!confirmInput.value || confirmInput.value !== passwordInput.value) {
                    confirmError.style.display = 'block';
                    confirmInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    confirmError.style.display = 'none';
                    confirmInput.classList.remove('finova-form-input--error');
                }

                // Validate Terms Checkbox
                if (!termsInput.checked) {
                    termsError.style.display = 'block';
                    isValid = false;
                } else {
                    termsError.style.display = 'none';
                }

                if (isValid) {
                    // Display demonstration registration disclaimer
                    feedbackAlert.className = 'finova-alert finova-alert--success';
                    feedbackIcon.innerHTML = '&#10003;';
                    feedbackMsg.textContent = 'This is a demonstration registration form. No account has been created and no information has been saved.';
                    feedbackAlert.style.display = 'flex';

                    // Reset form without saving
                    signUpForm.reset();
                }
            });
        }

        // ==========================================
        // 3. Contact Form Handler
        // ==========================================
        const contactForm = document.getElementById('finovaContactForm');
        if (contactForm) {
            const nameInput = document.getElementById('contactName');
            const emailInput = document.getElementById('contactEmail');
            const subjectInput = document.getElementById('contactSubject');
            const messageInput = document.getElementById('contactMessage');

            const nameError = document.getElementById('contactNameError');
            const emailError = document.getElementById('contactEmailError');
            const subjectError = document.getElementById('contactSubjectError');
            const messageError = document.getElementById('contactMessageError');

            const feedbackAlert = document.getElementById('contactFeedbackAlert');
            const feedbackMsg = document.getElementById('contactFeedbackMessage');
            const feedbackIcon = document.getElementById('contactFeedbackIcon');

            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                let isValid = true;

                if (!nameInput.value.trim()) {
                    nameError.style.display = 'block';
                    nameInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    nameError.style.display = 'none';
                    nameInput.classList.remove('finova-form-input--error');
                }

                if (!emailInput.value.trim() || !EMAIL_REGEX.test(emailInput.value.trim())) {
                    emailError.style.display = 'block';
                    emailInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    emailError.style.display = 'none';
                    emailInput.classList.remove('finova-form-input--error');
                }

                if (!subjectInput.value.trim()) {
                    subjectError.style.display = 'block';
                    subjectInput.classList.add('finova-form-input--error');
                    isValid = false;
                } else {
                    subjectError.style.display = 'none';
                    subjectInput.classList.remove('finova-form-input--error');
                }

                if (!messageInput.value.trim()) {
                    messageError.style.display = 'block';
                    messageInput.classList.add('finova-form-textarea--error');
                    isValid = false;
                } else {
                    messageError.style.display = 'none';
                    messageInput.classList.remove('finova-form-textarea--error');
                }

                if (isValid) {
                    feedbackAlert.className = 'finova-alert finova-alert--info';
                    feedbackIcon.innerHTML = '&#9432;';
                    feedbackMsg.textContent = 'This is a demonstration form. Your message has not been sent to a real support team.';
                    feedbackAlert.style.display = 'flex';

                    contactForm.reset();
                }
            });
        }
    });
})();
