/**
 * Finova Financial Services - Interactive Client-Side Script
 */

(function () {
    'use strict';

    function initFinovaNavigation() {
        var toggleBtn = document.getElementById('finovaMobileMenuToggle');
        var mobileDrawer = document.getElementById('finovaMobileDrawer');

        if (!toggleBtn || !mobileDrawer) {
            return;
        }

        toggleBtn.addEventListener('click', function () {
            var expanded = toggleBtn.getAttribute('aria-expanded') === 'true';
            toggleBtn.setAttribute('aria-expanded', !expanded);
            mobileDrawer.classList.toggle('is-open', !expanded);
            mobileDrawer.setAttribute('aria-hidden', expanded);
        });

        // Close mobile drawer when clicking a navigation link
        var drawerLinks = mobileDrawer.querySelectorAll('a');
        drawerLinks.forEach(function (link) {
            link.addEventListener('click', function () {
                toggleBtn.setAttribute('aria-expanded', 'false');
                mobileDrawer.classList.remove('is-open');
                mobileDrawer.setAttribute('aria-hidden', 'true');
            });
        });
    }

    function initSmoothScroll() {
        // Smooth scroll for hash links with offset for sticky header
        document.addEventListener('click', function (e) {
            var target = e.target.closest('a[href^="#"]');
            if (!target) return;

            var hash = target.getAttribute('href');
            if (!hash || hash === '#' || hash === '#login' || hash === '#open-account') return;

            var targetElem = document.querySelector(hash);
            if (targetElem) {
                e.preventDefault();
                var header = document.querySelector('.finova-header');
                var headerOffset = header ? header.offsetHeight : 0;
                var elementPosition = targetElem.getBoundingClientRect().top + window.pageYOffset;
                var offsetPosition = elementPosition - headerOffset - 20;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            initFinovaNavigation();
            initSmoothScroll();
        });
    } else {
        initFinovaNavigation();
        initSmoothScroll();
    }
})();
