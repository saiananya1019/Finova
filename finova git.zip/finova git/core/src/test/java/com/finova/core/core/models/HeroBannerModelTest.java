package com.finova.core.core.models;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(AemContextExtension.class)
class HeroBannerModelTest {

    private HeroBannerModel hero;

    @BeforeEach
    public void setup(AemContext context) {
        Resource resource = context.create().resource("/content/finova/herobanner",
                "sling:resourceType", "finova/components/herobanner",
                "heading", "Custom Banking Title",
                "primaryCtaLabel", "Start Today",
                "primaryCtaLink", "/content/finova/register");

        hero = resource.adaptTo(HeroBannerModel.class);
    }

    @Test
    void testHeroBannerModel() {
        assertNotNull(hero);
        assertEquals("Custom Banking Title", hero.getHeading());
        assertEquals("Start Today", hero.getPrimaryCtaLabel());
        assertEquals("/content/finova/register", hero.getPrimaryCtaLink());
        assertEquals("Open an Account", hero.getSecondaryCtaLabel());
    }
}
