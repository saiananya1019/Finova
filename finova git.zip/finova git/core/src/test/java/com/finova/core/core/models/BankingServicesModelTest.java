package com.finova.core.core.models;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(AemContextExtension.class)
class BankingServicesModelTest {

    private BankingServicesModel services;

    @BeforeEach
    public void setup(AemContext context) {
        Resource resource = context.create().resource("/content/finova/services",
                "sling:resourceType", "finova/components/bankingservices",
                "heading", "Our Banking Services",
                "card1Title", "High-Yield Savings");

        services = resource.adaptTo(BankingServicesModel.class);
    }

    @Test
    void testBankingServicesModel() {
        assertNotNull(services);
        assertEquals("Our Banking Services", services.getHeading());
        assertNotNull(services.getCards());
        assertEquals(4, services.getCards().size());
        assertEquals("High-Yield Savings", services.getCards().get(0).getTitle());
        assertEquals("Digital Banking", services.getCards().get(1).getTitle());
    }
}
