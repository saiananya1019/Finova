package com.finova.core.core.models;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class QuickLinksModel {

    @ValueMapValue
    @Default(values = "Quick Access")
    private String heading;

    @ValueMapValue
    @Default(values = "Frequently accessed banking tools and services:")
    private String subtitle;

    @ValueMapValue
    @Default(values = "Banking Services")
    private String link1Title;
    @ValueMapValue
    @Default(values = "#services")
    private String link1Url;

    @ValueMapValue
    @Default(values = "Digital Banking")
    private String link2Title;
    @ValueMapValue
    @Default(values = "#digital-banking")
    private String link2Url;

    @ValueMapValue
    @Default(values = "Money Transfers")
    private String link3Title;
    @ValueMapValue
    @Default(values = "#transfers")
    private String link3Url;

    @ValueMapValue
    @Default(values = "Customer Support")
    private String link4Title;
    @ValueMapValue
    @Default(values = "#support")
    private String link4Url;

    private List<QuickLinkItem> links;

    @PostConstruct
    protected void init() {
        if (heading == null || heading.trim().isEmpty()) {
            heading = "Quick Access";
        }
        links = new ArrayList<>();
        links.add(new QuickLinkItem(defaultIfEmpty(link1Title, "Banking Services"), defaultIfEmpty(link1Url, "#services"), "service"));
        links.add(new QuickLinkItem(defaultIfEmpty(link2Title, "Digital Banking"), defaultIfEmpty(link2Url, "#digital-banking"), "digital"));
        links.add(new QuickLinkItem(defaultIfEmpty(link3Title, "Money Transfers"), defaultIfEmpty(link3Url, "#transfers"), "transfer"));
        links.add(new QuickLinkItem(defaultIfEmpty(link4Title, "Customer Support"), defaultIfEmpty(link4Url, "#support"), "support"));
    }

    private String defaultIfEmpty(String val, String def) {
        return (val != null && !val.trim().isEmpty()) ? val : def;
    }

    public String getHeading() {
        return heading;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public List<QuickLinkItem> getLinks() {
        return links;
    }

    public static class QuickLinkItem {
        private final String title;
        private final String url;
        private final String type;

        public QuickLinkItem(String title, String url, String type) {
            this.title = title;
            this.url = url;
            this.type = type;
        }

        public String getTitle() {
            return title;
        }

        public String getUrl() {
            return url;
        }

        public String getType() {
            return type;
        }
    }
}
