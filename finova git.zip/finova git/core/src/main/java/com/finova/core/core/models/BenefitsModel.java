package com.finova.core.core.models;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class BenefitsModel {

    @ValueMapValue
    @Default(values = "The Finova Advantage")
    private String badgeText;

    @ValueMapValue
    @Default(values = "Why Choose Finova?")
    private String heading;

    @ValueMapValue
    @Default(values = "Designed with modern security, intuitive digital access, and dedicated support to keep you moving forward.")
    private String description;

    @ValueMapValue
    @Default(values = "Secure Banking")
    private String benefit1Title;

    @ValueMapValue
    @Default(values = "Protect your financial information with security-focused banking experiences.")
    private String benefit1Desc;

    @ValueMapValue
    @Default(values = "Convenient Access")
    private String benefit2Title;

    @ValueMapValue
    @Default(values = "Access banking services through a user-friendly digital experience.")
    private String benefit2Desc;

    @ValueMapValue
    @Default(values = "Transparent Services")
    private String benefit3Title;

    @ValueMapValue
    @Default(values = "Understand your banking options and make informed decisions.")
    private String benefit3Desc;

    @ValueMapValue
    @Default(values = "Customer Support")
    private String benefit4Title;

    @ValueMapValue
    @Default(values = "Find help and information when you need it.")
    private String benefit4Desc;

    private List<BenefitItem> items;

    @PostConstruct
    protected void init() {
        if (heading == null || heading.trim().isEmpty()) {
            heading = "Why Choose Finova?";
        }
        if (description == null || description.trim().isEmpty()) {
            description = "Designed with modern security, intuitive digital access, and dedicated support to keep you moving forward.";
        }

        items = new ArrayList<>();
        items.add(new BenefitItem(
                defaultIfEmpty(benefit1Title, "Secure Banking"),
                defaultIfEmpty(benefit1Desc, "Protect your financial information with security-focused banking experiences."),
                "security"
        ));
        items.add(new BenefitItem(
                defaultIfEmpty(benefit2Title, "Convenient Access"),
                defaultIfEmpty(benefit2Desc, "Access banking services through a user-friendly digital experience."),
                "access"
        ));
        items.add(new BenefitItem(
                defaultIfEmpty(benefit3Title, "Transparent Services"),
                defaultIfEmpty(benefit3Desc, "Understand your banking options and make informed decisions."),
                "transparency"
        ));
        items.add(new BenefitItem(
                defaultIfEmpty(benefit4Title, "Customer Support"),
                defaultIfEmpty(benefit4Desc, "Find help and information when you need it."),
                "support"
        ));
    }

    private String defaultIfEmpty(String val, String def) {
        return (val != null && !val.trim().isEmpty()) ? val : def;
    }

    public String getBadgeText() {
        return badgeText;
    }

    public String getHeading() {
        return heading;
    }

    public String getDescription() {
        return description;
    }

    public List<BenefitItem> getItems() {
        return items;
    }

    public static class BenefitItem {
        private final String title;
        private final String description;
        private final String iconType;

        public BenefitItem(String title, String description, String iconType) {
            this.title = title;
            this.description = description;
            this.iconType = iconType;
        }

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getIconType() {
            return iconType;
        }
    }
}
