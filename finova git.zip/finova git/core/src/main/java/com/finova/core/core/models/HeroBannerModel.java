package com.finova.core.core.models;

import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HeroBannerModel {

    @ValueMapValue
    @Default(values = "Smart Digital Banking")
    private String badgeText;

    @ValueMapValue
    @Default(values = "Banking That Moves With You")
    private String heading;

    @ValueMapValue
    @Default(values = "Discover simpler, smarter ways to manage your money with Finova Financial Services. Personal banking, loans, and credit cards tailored to your financial journey.")
    private String description;

    @ValueMapValue
    @Default(values = "Explore Services")
    private String primaryCtaLabel;

    @ValueMapValue
    @Default(values = "/content/finova/us/en/banking-services.html")
    private String primaryCtaLink;

    @ValueMapValue
    @Default(values = "Open an Account")
    private String secondaryCtaLabel;

    @ValueMapValue
    @Default(values = "/content/finova/us/en/sign-up.html")
    private String secondaryCtaLink;

    @ValueMapValue
    private String fileReference;

    @ValueMapValue
    @Default(values = "Finova Financial Services Hero Banner")
    private String altText;

    @PostConstruct
    protected void init() {
        if (heading == null || heading.trim().isEmpty()) {
            heading = "Banking That Moves With You";
        }
        if (description == null || description.trim().isEmpty()) {
            description = "Discover simpler, smarter ways to manage your money with Finova Financial Services. Personal banking, loans, and credit cards tailored to your financial journey.";
        }
        if (primaryCtaLabel == null || primaryCtaLabel.trim().isEmpty()) {
            primaryCtaLabel = "Explore Services";
        }
        if (primaryCtaLink == null || primaryCtaLink.trim().isEmpty()) {
            primaryCtaLink = "/content/finova/us/en/banking-services.html";
        }
        if (secondaryCtaLabel == null || secondaryCtaLabel.trim().isEmpty()) {
            secondaryCtaLabel = "Open an Account";
        }
        if (secondaryCtaLink == null || secondaryCtaLink.trim().isEmpty()) {
            secondaryCtaLink = "/content/finova/us/en/sign-up.html";
        }
    }

    public String getBadgeText() {
        return badgeText;
    }

    public String getHeading() {
        return heading;
    }

    public String getDescription() {
        return description;
    }

    public String getPrimaryCtaLabel() {
        return primaryCtaLabel;
    }

    public String getPrimaryCtaLink() {
        return primaryCtaLink;
    }

    public String getSecondaryCtaLabel() {
        return secondaryCtaLabel;
    }

    public String getSecondaryCtaLink() {
        return secondaryCtaLink;
    }

    public String getFileReference() {
        return fileReference;
    }

    public String getAltText() {
        return altText;
    }

    public boolean hasCustomImage() {
        return fileReference != null && !fileReference.trim().isEmpty();
    }
}
