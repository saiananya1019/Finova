package com.finova.core.core.models;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class BankingServicesModel {

    @ValueMapValue
    @Default(values = "Financial Solutions")
    private String badgeText;

    @ValueMapValue
    @Default(values = "Our Banking Services")
    private String heading;

    @ValueMapValue
    @Default(values = "Banking made simpler, smarter, and more convenient. Explore financial services designed around your everyday needs.")
    private String description;

    // Card 1
    @ValueMapValue
    @Default(values = "Savings Accounts")
    private String card1Title;

    @ValueMapValue
    @Default(values = "Build your savings with convenient account management.")
    private String card1Desc;

    @ValueMapValue
    @Default(values = "#savings")
    private String card1Link;

    @ValueMapValue
    @Default(values = "savings")
    private String card1Icon;

    // Card 2
    @ValueMapValue
    @Default(values = "Digital Banking")
    private String card2Title;

    @ValueMapValue
    @Default(values = "Access your banking services whenever you need them.")
    private String card2Desc;

    @ValueMapValue
    @Default(values = "#digital-banking")
    private String card2Link;

    @ValueMapValue
    @Default(values = "digital")
    private String card2Icon;

    // Card 3
    @ValueMapValue
    @Default(values = "Money Transfers")
    private String card3Title;

    @ValueMapValue
    @Default(values = "Transfer money conveniently and securely.")
    private String card3Desc;

    @ValueMapValue
    @Default(values = "#transfers")
    private String card3Link;

    @ValueMapValue
    @Default(values = "transfers")
    private String card3Icon;

    // Card 4
    @ValueMapValue
    @Default(values = "Account Management")
    private String card4Title;

    @ValueMapValue
    @Default(values = "Manage your account and track everyday banking activities.")
    private String card4Desc;

    @ValueMapValue
    @Default(values = "#account-mgmt")
    private String card4Link;

    @ValueMapValue
    @Default(values = "management")
    private String card4Icon;

    private List<ServiceCard> cards;

    @PostConstruct
    protected void init() {
        if (heading == null || heading.trim().isEmpty()) {
            heading = "Our Banking Services";
        }
        if (description == null || description.trim().isEmpty()) {
            description = "Banking made simpler, smarter, and more convenient. Explore financial services designed around your everyday needs.";
        }

        cards = new ArrayList<>();
        cards.add(new ServiceCard(
                defaultIfEmpty(card1Title, "Savings Accounts"),
                defaultIfEmpty(card1Desc, "Build your savings with convenient account management."),
                defaultIfEmpty(card1Link, "#savings"),
                defaultIfEmpty(card1Icon, "savings"),
                "01"
        ));
        cards.add(new ServiceCard(
                defaultIfEmpty(card2Title, "Digital Banking"),
                defaultIfEmpty(card2Desc, "Access your banking services whenever you need them."),
                defaultIfEmpty(card2Link, "#digital-banking"),
                defaultIfEmpty(card2Icon, "digital"),
                "02"
        ));
        cards.add(new ServiceCard(
                defaultIfEmpty(card3Title, "Money Transfers"),
                defaultIfEmpty(card3Desc, "Transfer money conveniently and securely."),
                defaultIfEmpty(card3Link, "#transfers"),
                defaultIfEmpty(card3Icon, "transfers"),
                "03"
        ));
        cards.add(new ServiceCard(
                defaultIfEmpty(card4Title, "Account Management"),
                defaultIfEmpty(card4Desc, "Manage your account and track everyday banking activities."),
                defaultIfEmpty(card4Link, "#account-mgmt"),
                defaultIfEmpty(card4Icon, "management"),
                "04"
        ));
    }

    private String defaultIfEmpty(String val, String def) {
        return (val != null && !val.trim().isEmpty()) ? val : def;
    }

    public String getBadgeText() {
        return badgeText;
    }

    public String getHeading() {
        return heading;
    }

    public String getDescription() {
        return description;
    }

    public List<ServiceCard> getCards() {
        return cards;
    }

    public static class ServiceCard {
        private final String title;
        private final String description;
        private final String link;
        private final String icon;
        private final String number;

        public ServiceCard(String title, String description, String link, String icon, String number) {
            this.title = title;
            this.description = description;
            this.link = link;
            this.icon = icon;
            this.number = number;
        }

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getLink() {
            return link;
        }

        public String getIcon() {
            return icon;
        }

        public String getNumber() {
            return number;
        }
    }
}
