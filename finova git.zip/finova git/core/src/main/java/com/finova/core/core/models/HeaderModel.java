package com.finova.core.core.models;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class HeaderModel {

    @ValueMapValue
    @Default(values = "Finova")
    private String logoText;

    @ValueMapValue
    @Default(values = "Financial Services")
    private String logoTagline;

    @ValueMapValue
    @Default(values = "/content/finova/us/en.html")
    private String logoLink;

    @ValueMapValue
    @Default(values = "Sign In")
    private String loginLabel;

    @ValueMapValue
    @Default(values = "/content/finova/us/en/sign-in.html")
    private String loginLink;

    @ValueMapValue
    @Default(values = "Open Account")
    private String openAccountLabel;

    @ValueMapValue
    @Default(values = "/content/finova/us/en/sign-up.html")
    private String openAccountLink;

    private List<NavItem> navItems;
    private List<NavItem> bankingServicesSubItems;

    @PostConstruct
    protected void init() {
        if (logoText == null || logoText.trim().isEmpty()) {
            logoText = "Finova";
        }
        if (logoTagline == null || logoTagline.trim().isEmpty()) {
            logoTagline = "Financial Services";
        }
        if (logoLink == null || logoLink.trim().isEmpty()) {
            logoLink = "/content/finova/us/en.html";
        }
        if (loginLabel == null || loginLabel.trim().isEmpty()) {
            loginLabel = "Sign In";
        }
        if (loginLink == null || loginLink.trim().isEmpty() || loginLink.equals("#login")) {
            loginLink = "/content/finova/us/en/sign-in.html";
        }
        if (openAccountLabel == null || openAccountLabel.trim().isEmpty()) {
            openAccountLabel = "Open Account";
        }
        if (openAccountLink == null || openAccountLink.trim().isEmpty() || openAccountLink.equals("#open-account")) {
            openAccountLink = "/content/finova/us/en/sign-up.html";
        }

        // Sub-items under Banking Services (EMI Calculator preserved here)
        bankingServicesSubItems = new ArrayList<>();
        bankingServicesSubItems.add(new NavItem("Savings Accounts", "/content/finova/us/en/savings-accounts.html", false));
        bankingServicesSubItems.add(new NavItem("Digital Banking", "/content/finova/us/en/digital-banking.html", false));
        bankingServicesSubItems.add(new NavItem("Credit Cards", "/content/finova/us/en/credit-cards.html", false));
        bankingServicesSubItems.add(new NavItem("Loans & Mortgages", "/content/finova/us/en/loans.html", false));
        bankingServicesSubItems.add(new NavItem("EMI Calculator", "/content/finova/us/en/emi-calculator.html", false));

        // Primary navigation items (EMI Calculator removed from top-level)
        navItems = new ArrayList<>();
        navItems.add(new NavItem("Home", "/content/finova/us/en.html", true));
        navItems.add(new NavItem("Banking Services", "/content/finova/us/en/banking-services.html", false));
        navItems.add(new NavItem("Savings Accounts", "/content/finova/us/en/savings-accounts.html", false));
        navItems.add(new NavItem("Digital Banking", "/content/finova/us/en/digital-banking.html", false));
        navItems.add(new NavItem("Credit Cards", "/content/finova/us/en/credit-cards.html", false));
        navItems.add(new NavItem("Loans", "/content/finova/us/en/loans.html", false));
        navItems.add(new NavItem("About Us", "/content/finova/us/en/about-us.html", false));
        navItems.add(new NavItem("Contact Us", "/content/finova/us/en/contact-us.html", false));
        navItems.add(new NavItem("Help & FAQs", "/content/finova/us/en/help-faqs.html", false));
    }

    public String getLogoText() {
        return logoText;
    }

    public String getLogoTagline() {
        return logoTagline;
    }

    public String getLogoLink() {
        return logoLink;
    }

    public String getLoginLabel() {
        return loginLabel;
    }

    public String getLoginLink() {
        return loginLink;
    }

    public String getOpenAccountLabel() {
        return openAccountLabel;
    }

    public String getOpenAccountLink() {
        return openAccountLink;
    }

    public List<NavItem> getNavItems() {
        return navItems;
    }

    public List<NavItem> getBankingServicesSubItems() {
        return bankingServicesSubItems;
    }

    public static class NavItem {
        private final String label;
        private final String link;
        private final boolean active;

        public NavItem(String label, String link, boolean active) {
            this.label = label;
            this.link = link;
            this.active = active;
        }

        public String getLabel() {
            return label;
        }

        public String getLink() {
            return link;
        }

        public boolean isActive() {
            return active;
        }
    }
}
