package com.finova.core.core.models;

import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PromotionalCtaModel {

    @ValueMapValue
    @Default(values = "Start Today")
    private String badgeText;

    @ValueMapValue
    @Default(values = "Your Financial Journey Starts Here")
    private String heading;

    @ValueMapValue
    @Default(values = "Explore banking solutions designed to make managing your money simpler.")
    private String description;

    @ValueMapValue
    @Default(values = "Get Started")
    private String buttonLabel;

    @ValueMapValue
    @Default(values = "#get-started")
    private String buttonLink;

    @PostConstruct
    protected void init() {
        if (heading == null || heading.trim().isEmpty()) {
            heading = "Your Financial Journey Starts Here";
        }
        if (description == null || description.trim().isEmpty()) {
            description = "Explore banking solutions designed to make managing your money simpler.";
        }
        if (buttonLabel == null || buttonLabel.trim().isEmpty()) {
            buttonLabel = "Get Started";
        }
        if (buttonLink == null || buttonLink.trim().isEmpty()) {
            buttonLink = "#get-started";
        }
    }

    public String getBadgeText() {
        return badgeText;
    }

    public String getHeading() {
        return heading;
    }

    public String getDescription() {
        return description;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getButtonLink() {
        return buttonLink;
    }
}
