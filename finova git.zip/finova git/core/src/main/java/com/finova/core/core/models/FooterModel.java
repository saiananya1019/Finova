package com.finova.core.core.models;

import javax.annotation.PostConstruct;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class FooterModel {

    @ValueMapValue
    @Default(values = "Finova Financial Services")
    private String brandName;

    @ValueMapValue
    @Default(values = "Finova is a modern financial services platform designed for demonstration and learning. Explore simpler, smarter ways to manage your money with intuitive digital banking.")
    private String brandDescription;

    @ValueMapValue
    @Default(values = "support@finova-demo.com")
    private String contactEmail;

    @ValueMapValue
    @Default(values = "1-800-FINOVA")
    private String contactPhone;

    @ValueMapValue
    @Default(values = "Mon - Fri: 9:00 AM - 6:00 PM EST")
    private String contactHours;

    @ValueMapValue
    @Default(values = "© 2026 Finova Financial Services. All rights reserved. For demonstration and educational purposes only.")
    private String copyrightText;

    @PostConstruct
    protected void init() {
        if (brandName == null || brandName.trim().isEmpty()) {
            brandName = "Finova Financial Services";
        }
        if (brandDescription == null || brandDescription.trim().isEmpty()) {
            brandDescription = "Finova is a modern financial services platform designed for demonstration and learning. Explore simpler, smarter ways to manage your money with intuitive digital banking.";
        }
        if (contactEmail == null || contactEmail.trim().isEmpty()) {
            contactEmail = "support@finova-demo.com";
        }
        if (contactPhone == null || contactPhone.trim().isEmpty()) {
            contactPhone = "1-800-FINOVA";
        }
        if (contactHours == null || contactHours.trim().isEmpty()) {
            contactHours = "Mon - Fri: 9:00 AM - 6:00 PM EST";
        }
        if (copyrightText == null || copyrightText.trim().isEmpty()) {
            copyrightText = "© 2026 Finova Financial Services. All rights reserved. For demonstration and educational purposes only.";
        }
    }

    public String getBrandName() {
        return brandName;
    }

    public String getBrandDescription() {
        return brandDescription;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public String getContactHours() {
        return contactHours;
    }

    public String getCopyrightText() {
        return copyrightText;
    }
}
